export const ADD_CART = "ADD_CART"
export const REMOVE = "REMOVE"
export const REMOVE_ITEM = "REMOVE_ITEM"