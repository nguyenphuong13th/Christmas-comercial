import React from 'react'

export const Footer = () => {
  return (
    <>
      <footer>
        <p>Copyright @ Anthony all rights to reserved. Power by NHP</p>
      </footer>
    </>
  )
}
